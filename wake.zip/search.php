<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donor Information</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
            text-align: left;
        }
        .hidden-details {
            display: none;
        }
        .show {
            display: table-row;
        }
        .read-more {
            cursor: pointer;
            color: blue;
            text-decoration: underline;
        }
    </style>
</head>
<body>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $host = "localhost";
    $username = "root";
    $password = "";
    $dbname = "wave";

    // Create connection
    $conn = new mysqli($host, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Sanitize inputs
    $state = $conn->real_escape_string($_POST['state']);
    $district = $conn->real_escape_string($_POST['district']);
    $bloodGroup = $conn->real_escape_string($_POST['bloodType']);

    // Retrieve data from the 'donor' table based on filters
    $sql = "SELECT `name`, `phone_number`, `State`, `District`, `Pincode`, `bloodgroup`, `email`, `age`, `Health` FROM donor WHERE `State` = '$state' AND `District` = '$district' AND `bloodgroup` = '$bloodGroup'";
    $result = $conn->query($sql);

    if ($result === false) {
        echo "Error in query: " . $conn->error;
    } else if ($result->num_rows > 0) {
        echo "DONORS DETAILS";
        echo "<table>";
        echo "<tr><th>Name</th><th>Phone Number</th><th>State</th><th>District</th><th>Blood Group</th><th>Read More</th></tr>";
        
        // Output data of each row
        $rowIndex = 0;
        while($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>{$row['name']}</td>
                    <td>{$row['phone_number']}</td>
                    <td>{$row['State']}</td>
                    <td>{$row['District']}</td>
                    <td>{$row['bloodgroup']}</td>
                    <td class='read-more' data-index='$rowIndex'>Read More</td>
                  </tr>";
            echo "<tr class='hidden-details' id='details-$rowIndex'>
                    <td colspan='6'>
                        <strong>Pincode:</strong> {$row['Pincode']}<br>
                        <strong>Email:</strong> {$row['email']}<br>
                        <strong>Age:</strong> {$row['age']}<br>
                        <strong>Health:</strong> {$row['Health']}<br>
                        <button onclick='acceptDonor(\"{$row['email']}\", \"{$row['name']}\", \"{$row['phone_number']}\")'>Accept</button>
                        <button onclick='rejectDonor()'>Reject</button>
                    </td>
                  </tr>";
            $rowIndex++;
        }
        echo "</table>";
    } else {
        echo "No donor records found matching the criteria.";
    }

    // Close connection
    $conn->close();
}
?>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.read-more').forEach(function(element) {
            element.addEventListener('click', function() {
                const index = this.getAttribute('data-index');
                const detailsRow = document.getElementById('details-' + index);
                detailsRow.classList.toggle('show');
            });
        });
    });

    function acceptDonor(email, name, phone) {
        if (confirm("Do you want to accept this donor?")) {
            const xhr = new XMLHttpRequest();
            xhr.open("POST", "send_email.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    alert("Email sent to the donor.");
                }
            };
            xhr.send("email=" + email + "&name=" + name + "&phone=" + phone);
        }
    }

    function rejectDonor() {
        alert("Donor rejected.");
    }
</script>

</body>
</html>
