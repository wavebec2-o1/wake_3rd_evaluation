<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Campaign Information</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
            text-align: left;
        }
    </style>
</head>
<body>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $host = "localhost";
    $username = "root";
    $password = "";
    $dbname = "wave";

    // Create connection
    $conn = new mysqli($host, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Sanitize inputs
    $city = $conn->real_escape_string($_POST['city']);

    // Retrieve data from the 'campaigns' table based on city
    $sql = "SELECT `name`, `phone`, `email`, `camName`, `date`, `time`, `City`, `camLoc`, `camDesc` FROM campaigns WHERE `City` = '$city'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<h2>Nearby Campaigns</h2>";
        echo "<table>";
        echo "<tr><th>Organization Name</th><th>Contact Phone</th><th>Contact Email</th><th>Campaign Name</th><th>Date</th><th>Time</th><th>Location</th><th>Description</th></tr>";
        
        // Output data of each row
        while($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>{$row['name']}</td>
                    <td>{$row['phone']}</td>
                    <td>{$row['email']}</td>
                    <td>{$row['camName']}</td>
                    <td>{$row['date']}</td>
                    <td>{$row['time']}</td>
                    <td>{$row['camLoc']}</td>
                    <td>{$row['camDesc']}</td>
                  </tr>";
        }
        echo "</table>";
    } else {
        echo "No campaigns found for the selected city.";
    }

    // Close connection
    $conn->close();
}
?>

</body>
</html>
